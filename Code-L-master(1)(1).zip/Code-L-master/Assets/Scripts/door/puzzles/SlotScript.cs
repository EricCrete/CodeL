using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class SlotScript : MonoBehaviour, IDropHandler
{
    public int id;
    private int currentPoints;
    public int pointsToWin;
    public GameObject myCanvas;
    [SerializeField] private DoorSetActive door;


    public void OnDrop(PointerEventData eventData)
    {
        Debug.Log("ItemDropped");
        if (eventData.pointerDrag != null)
        {
            if(eventData.pointerDrag.GetComponent<DragAndDrop>().id == id)
            {
                //eventData.pointerDrag.GetComponent<RectTransform>().anchoredPosition = this.GetComponent<RectTransform>().anchoredPosition;
                AddPoints();
                Debug.Log(currentPoints);
            }
            else
            {
                eventData.pointerDrag.GetComponent<DragAndDrop>().ResetPosition();
            }
            
        }
    }
    public void AddPoints()
    {
        currentPoints++;
    }
    private void Update()
    {
        if(currentPoints >= pointsToWin)
        {
            myCanvas.SetActive(false);
            door.OpenDoor();
        }
    }
}
