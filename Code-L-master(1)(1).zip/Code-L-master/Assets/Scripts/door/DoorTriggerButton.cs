using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorTriggerButton : MonoBehaviour
{
    [SerializeField] private DoorSetActive door;
    bool isColliding;
    public GameObject myCanvas;

    private void Update()
    {
        if (isColliding)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                Debug.Log("Clicked");
                myCanvas.SetActive(true);

                //if(!myCanvas.activeSelf)
                //{
                //    door.OpenDoor();
                //}
            }
            if (Input.GetKeyDown(KeyCode.G))
            {
                door.CloseDoor();
            }
        }

    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        isColliding= true;
        Debug.Log("ENTEREDD");

    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        isColliding = false;
        Debug.Log("LEFT");
    }
}
