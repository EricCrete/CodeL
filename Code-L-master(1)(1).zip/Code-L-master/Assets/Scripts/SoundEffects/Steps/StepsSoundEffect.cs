using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StepsSoundEffect : MonoBehaviour
{
    public AudioSource Step;

    public void PlayStep()
    {
        Step.Play();
    }
       
        
}
