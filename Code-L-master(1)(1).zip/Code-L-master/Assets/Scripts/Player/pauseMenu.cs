using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class pauseMenu : MonoBehaviour
{
    public static bool isGamePaused = false;

    [SerializeField] GameObject PauseMenu;
    [SerializeField] GameObject OptionsLabel;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isGamePaused)
            {
                ResumeGame();
            }
            else
            {
                PauseGame();
            }
        }
    }

    public void ResumeGame()
    {
        PauseMenu.SetActive(false);
        Time.timeScale = 1f;
        isGamePaused = false;
    }
    private void PauseGame()
    {
        PauseMenu.SetActive(true);
        Time.timeScale = 0f;
        isGamePaused = true;
    }
    public void LoadMenu()
    {
        PauseMenu.SetActive(false);
        OptionsLabel.SetActive(true);
    }
    public void QuitGame()
    {
        Application.Quit();

        Debug.Log("quit");
    }
    public void QuitLoadMenu()
    {
        OptionsLabel.SetActive(false);
        PauseMenu.SetActive(true);
    }
}
