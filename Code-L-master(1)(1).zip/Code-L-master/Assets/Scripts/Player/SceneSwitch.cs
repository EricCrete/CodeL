using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwitch : MonoBehaviour
{
    public int Scene;
    public string SceneString;
    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Trigger Enterred");

        if (other.tag == "Player" )
        {

            Debug.Log("Space key was pressed.");
            Initiate.Fade(SceneString, Color.black, 0.5f);
            //SceneManager.LoadScene(Scene, LoadSceneMode.Single);
        }

    }

}

