using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Teleporter : MonoBehaviour
{
    public int Scene;
    private void OnTriggerEnter2D(Collider2D other)
    {
        print("Trigger Enterred");

        if(other.CompareTag("Player") && !other.isTrigger)
        {
            print("Switch scene");
            SceneManager.LoadScene(Scene);
        }

    }
}
